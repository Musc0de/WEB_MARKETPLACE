# Gooey Toast QA Checklist

- Exactly one toaster per app.
- Package stylesheet imported once.
- Desktop top-right.
- Mobile bottom-center.
- Correct offset above bottom nav/sticky CTA/safe-area.
- Queue and maximum visible behavior.
- Hover pause desktop.
- Swipe/close mobile when supported.
- Promise update does not duplicate.
- Action keyboard/touch accessible.
- Reduced motion.
- No credential-only or payment-only feedback through toast.
