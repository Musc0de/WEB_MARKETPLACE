# Storefront UI QA Checklist

- Home, product list, product detail desktop/mobile.
- Search/filter/sort URL state.
- Product card sold/rating/stock/price.
- Guest wishlist/cart.
- Login merge conflict.
- Cart totals server result.
- Checkout physical, digital, and mixed.
- Stock/price change.
- Payment pending/failure/success.
- Sticky CTA and toast offset.
- 320px no overflow.
