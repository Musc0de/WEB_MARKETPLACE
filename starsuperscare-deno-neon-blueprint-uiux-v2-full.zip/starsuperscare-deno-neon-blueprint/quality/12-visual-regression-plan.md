# Visual Regression Plan

Capture baseline per critical page for:

- Desktop and mobile.
- Loading.
- Empty.
- Error.
- Filled/normal.
- Long content.
- Modal/sheet open.
- Toast visible.
- Sticky CTA/bottom nav.

Mask dynamic timestamps/order ids only when necessary. Do not mask layout areas that could hide regressions.
