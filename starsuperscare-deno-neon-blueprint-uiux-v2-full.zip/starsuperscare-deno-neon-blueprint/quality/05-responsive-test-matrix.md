# Responsive Test Matrix

Uji setiap critical page pada:

| Device class | Viewport |
|---|---|
| Small phone | 320×568 |
| Common Android | 360×800 |
| iPhone-like | 390×844 |
| Large phone | 412×915 |
| Tablet portrait | 768×1024 |
| Tablet landscape | 1024×768 |
| Laptop | 1280×720 |
| Desktop | 1440×900 |
| Wide desktop | 1920×1080 |

Tambahkan test keyboard open, 200% zoom, landscape phone, long Indonesian text, large price/order id, empty/error/loading, dan safe-area.
