# Accessibility and Motion QA

- Keyboard-only completion.
- Focus visible and restored after overlay.
- Screen reader labels/live regions.
- Heading/landmark hierarchy.
- 200% zoom.
- Contrast.
- Touch target.
- Reduced motion.
- Error summary and field relationship.
- Table/card mobile adaptation.
- Toast does not steal focus.
