# Dashboard Client UI QA Checklist

- Shell/nav desktop/mobile.
- Home summary.
- Profile/security/session.
- Orders/tracking/history.
- Invoice/download.
- Address/payment/wishlist.
- Notification REST + SSE/reconnect/dedupe.
- Returns/refunds.
- Support/reviews/settings.
- Permission/session expired.
- Toast does not replace persistent status.
