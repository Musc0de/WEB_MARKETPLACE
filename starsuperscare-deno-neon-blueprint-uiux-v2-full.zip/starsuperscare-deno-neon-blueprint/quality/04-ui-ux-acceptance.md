# UI/UX Acceptance Criteria

Sebuah feature UI dinyatakan selesai bila:

- Desktop dan mobile spec diterapkan.
- Loading, empty, error, permission, offline, and stale state tersedia.
- Button/action hierarchy jelas.
- Gooey Toast mengikuti responsive position dan event policy.
- Inline validation tetap tersedia.
- Keyboard, focus, screen reader, reduced motion, zoom 200%, dan contrast diuji.
- Route refresh/deep link bekerja.
- No horizontal overflow pada viewport wajib.
- API error tidak membocorkan secret/internal stack.
- Visual regression baseline tersedia untuk state utama.
