# Admin UI QA Checklist

- Admin auth/2FA.
- Role-aware nav and server permission errors.
- Tables/filter/sort/pagination.
- Product editor/variant/media.
- Inventory adjustment conflict/audit.
- Order/payment/refund status transition.
- Batch operation result summary.
- Support/review moderation.
- Mobile operational fallback.
- Production environment indicator.
