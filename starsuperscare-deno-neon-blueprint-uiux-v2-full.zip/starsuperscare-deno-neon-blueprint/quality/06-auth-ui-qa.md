# Auth UI QA Checklist

- Login username/password desktop/mobile.
- Password manager and autocomplete.
- Invalid credential generic error.
- Rate limit.
- Signup async username check.
- Verify email.
- Activation account auto-provision.
- Expired/used token.
- Forgot/reset password.
- Session expired return flow.
- Desktop top-right toast.
- Mobile bottom-center toast.
- Keyboard and screen reader.
